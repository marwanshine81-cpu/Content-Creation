# Marwan Mohamed Ahmed — Creative Media Portfolio

A single-page, self-contained portfolio website. No build step, no dependencies to install — just HTML, CSS, and JavaScript, plus the images in `assets/`.

## Folder structure

```
index.html          the whole site
assets/
  images/            certificates, photo (JPEG)
README.md            this file
```

## View it locally

Just double-click `index.html`, or open it in any browser. Everything works offline except the Google Fonts (needs internet for the custom typefaces; falls back to system fonts otherwise).

## Publish it for free with GitHub Pages

1. Create a new repository on GitHub (e.g. `marwan-portfolio`). Keep it **Public** so Pages can serve it for free.
2. Upload this whole folder to the repository:
   - Easiest way: on the repo page, click **Add file → Upload files**, drag in `index.html`, `README.md`, and the `assets` folder, then **Commit changes**.
   - Or with git, from inside this folder:
     ```
     git init
     git add .
     git commit -m "Initial portfolio"
     git branch -M main
     git remote add origin https://github.com/YOUR-USERNAME/marwan-portfolio.git
     git push -u origin main
     ```
3. In the repository, go to **Settings → Pages**.
4. Under "Build and deployment", set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`, then **Save**.
5. GitHub will publish the site at `https://YOUR-USERNAME.github.io/marwan-portfolio/` within a minute or two.

## About the "Manage page" pencil icon

The small pencil icon in the bottom-right corner lets you update the photo, phone/email, and some certificate images without editing code — but it only works while this page is opened as a Claude.ai artifact, because it relies on Claude's storage feature. On GitHub Pages (or any other host) there's no such backend, so the icon stays hidden automatically and updates there need a new file or a text edit — just replace the relevant file in `assets/`, or ask Claude to regenerate `index.html` with your changes.

The Video Projects placeholders in the Portfolio section aren't editable through that panel at all, even on Claude.ai — video files are too large for the storage system. To add a video, place the file into `assets/videos/` and ask Claude to point the right slot at it (or edit the `DEFAULT_DOCS` object near the top of the `<script>` tag in `index.html` yourself — each entry is just a relative file path).

## Recent changes

The Creative Experience section (which held two video samples) and the References section have both been removed at your request. The two video files are no longer part of this package.
